const navbar = () => {
    if (navbar){
    document.getElementById('navbar').style.display = 'block'
    }
}